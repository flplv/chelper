cpputest
========

CppUTest unit testing and mocking framework for C/C++

More information on the project page at:
http://cpputest.github.com/cpputest/
